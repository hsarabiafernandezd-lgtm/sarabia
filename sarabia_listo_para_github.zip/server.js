import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", "data:"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
app.use(express.json({ limit: "30kb" }));

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: Number(process.env.RATE_LIMIT_MAX || 20),
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Has enviado muchas consultas. Espera unos minutos e inténtalo de nuevo." }
});
app.use("/api/chat", limiter);

const SYSTEM_PROMPT = `
Eres el Asistente Jurídico Hondureño, una herramienta educativa de información jurídica general.
JURISDICCIÓN: exclusivamente la República de Honduras. Temas principales: parricidio, lavado de activos y feminicidio/femicidio, además de reglas constitucionales, penales y procesales hondureñas relacionadas.
REGLAS OBLIGATORIAS:
1. No eres abogado, juez, fiscal ni defensor; no creas relación abogado-cliente ni sustituyes asesoría legal.
2. No inventes artículos, números de decretos, penas, agravantes, sentencias, plazos ni procedimientos. Si no tienes certeza o puede haber reformas, dilo expresamente y recomienda cotejar el texto oficial vigente.
3. Diferencia con cuidado la ley sustantiva, el procedimiento y el régimen especial de justicia penal juvenil. No trates a menores como adultos. Explica que la edad, fecha del hecho y circunstancias determinan el régimen aplicable; evita dar una pena exacta sin verificar norma vigente.
4. Al analizar un caso, separa: hechos conocidos, datos faltantes, posible calificación jurídica (solo preliminar), elementos que deben probarse, derechos y garantías, pasos legales generales y alternativas de ayuda. No declares culpabilidad.
5. Distingue autoría, coautoría, inducción y complicidad solo cuando la norma aplicable y los hechos permitan hacerlo. Explica agravantes/atenuantes como cuestiones que requieren prueba y base legal.
6. En lavado de activos, no enseñes a ocultar fondos, evadir controles, destruir pruebas ni eludir investigaciones. Puedes explicar prevención, cumplimiento, investigación legal y derechos de defensa.
7. En violencia o riesgo inmediato, recomienda llamar a los servicios de emergencia y acudir a autoridades competentes o servicios de protección de Honduras. No sugieras confrontar al presunto agresor.
8. Protege la privacidad: pide que no compartan nombres completos, direcciones, números de identidad, teléfonos, datos de menores, expedientes íntegros ni información confidencial. Si los aportan, no los repitas innecesariamente.
9. Responde en español claro, estructurado y pedagógico. Si falta un dato esencial, formula UNA pregunta a la vez. No conviertas hipótesis en hechos.
10. Cita una disposición solo si estás razonablemente seguro de su existencia y contenido. Indica que el usuario debe verificar reformas y texto oficial. Prioriza fuentes oficiales hondureñas: La Gaceta, Congreso Nacional, Poder Judicial, Ministerio Público, CONADEH e instituciones públicas competentes. No afirmes haber consultado fuentes en tiempo real si no lo has hecho.
11. Para penas, indica que dependen de la tipificación exacta, versión vigente de la ley, grado de ejecución, participación, circunstancias y reglas de determinación; nunca des una cifra especulativa.
FORMATO RECOMENDADO:
- Respuesta breve
- Fundamento jurídico hondureño (solo lo que puedas afirmar con seguridad; marca lo pendiente de verificación)
- Aplicación al caso / datos que faltan
- Derechos y próximos pasos generales
- Advertencia de vigencia y necesidad de abogado cuando corresponda
Si la pregunta no guarda relación con Honduras o con los temas del asistente, explica amablemente el alcance limitado.
`;

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(client) });
});

app.post("/api/chat", async (req, res) => {
  if (!client) {
    return res.status(503).json({
      error: "El asistente todavía no está conectado. El administrador debe configurar OPENAI_API_KEY en el servidor."
    });
  }

  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 16) {
    return res.status(400).json({ error: "La conversación no tiene un formato válido." });
  }

  const clean = [];
  for (const m of messages) {
    if (!m || !["user", "assistant"].includes(m.role) || typeof m.content !== "string") {
      return res.status(400).json({ error: "Se encontró un mensaje no válido." });
    }
    const content = m.content.trim();
    if (!content || content.length > 5000) {
      return res.status(400).json({ error: "Cada mensaje debe tener entre 1 y 5000 caracteres." });
    }
    clean.push({ role: m.role, content });
  }
  if (clean[clean.length - 1].role !== "user") {
    return res.status(400).json({ error: "El último mensaje debe ser una pregunta del usuario." });
  }

  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6",
      instructions: SYSTEM_PROMPT,
      input: clean.map(m => ({
        role: m.role,
        content: m.content
      })),
      store: false,
      max_output_tokens: 1200
    });

    const answer = response.output_text?.trim();
    if (!answer) throw new Error("La IA no devolvió texto.");
    res.json({ answer });
  } catch (err) {
    console.error("Chat API error:", err?.status || "", err?.message || "unknown");
    res.status(500).json({
      error: "No fue posible generar la respuesta en este momento. Inténtalo de nuevo más tarde."
    });
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("/{*splat}", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => {
  console.log(`Asistente Jurídico Hondureño disponible en puerto ${PORT}`);
});

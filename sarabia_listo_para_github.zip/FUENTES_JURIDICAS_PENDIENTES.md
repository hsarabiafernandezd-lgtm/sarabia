# Fuentes jurídicas hondureñas: lista de verificación antes del lanzamiento

Esta plantilla no sustituye la revisión jurídica. Completar y validar con una persona profesional del derecho en Honduras.

Para cada norma, registrar:
- Nombre oficial y número de decreto.
- Fecha de publicación en La Gaceta.
- Artículos relevantes.
- Reformas, derogaciones y vigencia a la fecha de revisión.
- Enlace a fuente oficial.
- Fecha de última verificación y responsable de revisión.

Fuentes institucionales a consultar:
- Diario Oficial La Gaceta.
- Congreso Nacional de Honduras.
- Poder Judicial de Honduras.
- Ministerio Público de Honduras.
- CONADEH y organismos públicos competentes para protección y derechos.

Materias a documentar:
1. Constitución de la República y garantías procesales.
2. Código Penal vigente y sus reformas: delitos contra la vida, parricidio y femicidio/feminicidio según denominación legal aplicable.
3. Legislación vigente sobre lavado de activos y sus reformas.
4. Código Procesal Penal y reglas de investigación, prueba, medidas cautelares y defensa.
5. Régimen especial de responsabilidad penal para adolescentes y normativa conexa.
6. Normativa de protección a mujeres y víctimas, medidas de seguridad y atención.
7. Jurisprudencia hondureña relevante, con número de expediente, órgano, fecha y enlace verificable.

No publicar penas concretas hasta cotejar el texto oficial consolidado y sus reformas.

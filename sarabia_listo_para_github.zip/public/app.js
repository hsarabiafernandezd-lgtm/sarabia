const messagesEl = document.getElementById("messages");
const form = document.getElementById("chatForm");
const input = document.getElementById("question");
const sendBtn = document.getElementById("sendBtn");
const history = [];

function addMessage(role, content, extraClass = "") {
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "Tú" : "⚖️";
  const bubble = document.createElement("div");
  bubble.className = `bubble ${extraClass}`;
  bubble.textContent = content;
  row.append(avatar, bubble);
  messagesEl.appendChild(row);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return bubble;
}

function removeWelcome() {
  const welcome = messagesEl.querySelector(".welcome");
  if (welcome) welcome.remove();
}

async function sendQuestion(question) {
  const clean = question.trim();
  if (!clean || sendBtn.disabled) return;
  removeWelcome();
  addMessage("user", clean);
  history.push({ role: "user", content: clean });
  input.value = "";
  input.style.height = "auto";
  sendBtn.disabled = true;
  const typing = addMessage("assistant", "Estoy analizando tu pregunta...");
  typing.classList.add("typing");

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history.slice(-16) })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "No se pudo completar la consulta.");
    typing.textContent = data.answer;
    typing.classList.remove("typing");
    history.push({ role: "assistant", content: data.answer });
  } catch (error) {
    typing.textContent = error.message || "Ocurrió un error. Intenta nuevamente.";
    typing.classList.remove("typing");
    typing.classList.add("error");
    history.pop();
  } finally {
    sendBtn.disabled = false;
    input.focus();
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendQuestion(input.value);
});

input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 140)}px`;
});

document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => sendQuestion(button.dataset.prompt));
});

document.getElementById("newChat").addEventListener("click", () => {
  history.length = 0;
  messagesEl.innerHTML = `
    <div class="welcome">
      <div class="welcome-icon">⚖️</div>
      <h1>¿En qué tema jurídico de Honduras puedo orientarte?</h1>
      <p>Escribe una pregunta abierta o selecciona un tema. Si falta un dato importante, te haré una pregunta a la vez.</p>
      <div class="suggestions">
        <button data-prompt="¿Qué diferencia existe entre parricidio y homicidio en Honduras?">Diferencia entre parricidio y homicidio</button>
        <button data-prompt="¿Cómo se investiga un posible caso de lavado de activos en Honduras?">Investigación de lavado de activos</button>
        <button data-prompt="¿Qué medidas de protección existen ante violencia contra una mujer en Honduras?">Medidas de protección</button>
      </div>
    </div>`;
  messagesEl.querySelectorAll("[data-prompt]").forEach(button =>
    button.addEventListener("click", () => sendQuestion(button.dataset.prompt))
  );
  input.focus();
});

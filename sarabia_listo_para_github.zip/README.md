# Asistente Jurídico Hondureño — versión web con IA

Aplicación web pública con chat abierto. Los visitantes no necesitan registrarse. El servidor usa la API de OpenAI y mantiene la clave secreta fuera del navegador.

## Qué incluye

- Chat abierto con preguntas libres.
- Atajos para parricidio, lavado de activos y feminicidio/femicidio.
- Prompt jurídico limitado a Honduras, con instrucciones contra la invención de artículos y penas.
- Preguntas aclaratorias de una en una cuando falten datos.
- Aviso de privacidad y de que no sustituye a un abogado.
- Límite básico de solicitudes por dirección IP.
- Historial solo en la memoria del navegador mientras la página está abierta; el servidor no guarda una base de datos de conversaciones.

## Requisitos

- Node.js 20 o superior.
- Una clave API de OpenAI con facturación/configuración habilitada.
- Un servicio de hosting que permita ejecutar Node.js.

## Ejecutar en tu computadora

1. Descomprime el proyecto.
2. Abre una terminal dentro de la carpeta.
3. Ejecuta `npm install`.
4. Copia `.env.example` a `.env`.
5. Abre `.env` y coloca tu clave en `OPENAI_API_KEY`. No compartas ese archivo.
6. Revisa `OPENAI_MODEL` y configúralo con un modelo disponible en tu cuenta de API.
7. Ejecuta `npm start`.
8. Abre `http://localhost:3000`.

Si el modelo configurado no está habilitado en tu cuenta, el administrador debe cambiar `OPENAI_MODEL` por el identificador de un modelo disponible.

## Publicar en internet (ejemplo con Render)

1. Crea una cuenta en GitHub y un repositorio privado para este proyecto.
2. Sube los archivos del proyecto, pero NO subas `.env` ni ninguna clave API.
3. Crea una cuenta en Render y elige **New → Web Service**.
4. Conecta el repositorio.
5. Configura:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
6. En la sección **Environment**, agrega:
   - `OPENAI_API_KEY` = tu clave secreta
   - `OPENAI_MODEL` = modelo disponible en tu cuenta
   - `RATE_LIMIT_MAX` = `20`
7. Despliega. Render te entregará una URL pública HTTPS que puedes compartir.
8. Prueba el chat desde una ventana privada y desde un teléfono.

Los nombres de menús y planes del proveedor de hosting pueden cambiar. Revisa sus precios, límites y condiciones antes de publicar.

## Seguridad y costos

- Nunca pongas la clave API en `public/app.js`, `index.html` ni en un repositorio público.
- El acceso sin registro significa que cualquier persona con el enlace podrá usar el servicio. La limitación por IP es una protección básica, no evita todo abuso.
- Configura alertas y límites de gasto en el proveedor de IA; el hosting y las consultas pueden generar costos.
- Para uso público real, considera CAPTCHA, monitoreo, límites por usuario/IP, protección contra abuso y una política de privacidad publicada.
- No solicites datos personales ni documentos judiciales confidenciales. Esta versión no persiste chats en una base de datos, pero las solicitudes se envían al proveedor de IA para generar respuestas y quedan sujetas a sus condiciones y políticas.
- Antes de su lanzamiento, un abogado hondureño debe revisar el contenido jurídico y probar las respuestas con legislación vigente.

## Importante sobre la precisión jurídica

Este proyecto es una base técnica funcional, no una base de datos jurídica oficial ni un sistema de consulta normativa en tiempo real. Para respuestas confiables sobre artículos y penas, incorpora y mantiene un repositorio verificado de textos oficiales vigentes (por ejemplo, publicaciones de La Gaceta y normativa del Congreso Nacional), con número de decreto, fecha, reformas y enlace oficial. No cargues material no autorizado ni expedientes personales.

## Estructura

- `server.js`: servidor y conexión privada con la API.
- `public/index.html`: interfaz.
- `public/styles.css`: diseño adaptable.
- `public/app.js`: interacción del chat.
- `.env.example`: variables de configuración de ejemplo.
